﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Net.Http;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using EF_TextCapture_Service;
using System.Net.Http;
using System.Net.Http.Headers;
using RestSharp.Authenticators;
using RestSharp;
//using Newtonsoft.Json;
//using Newtonsoft.Json.Linq;

namespace EF_TextCapture_Service
{
    class Program
    {
        static async Task Main(string[] args)
        {
            string hcurl;
            string lla_id = "chat594842024220242@conference-2-standaloneclustera3caf.lab.local";
            string language = "en-us";
            //string type = "Conversation";
            string sourceType = "ExpertFlow HybriChat";
            string project = "1503806";
            string channel = "1504806";
            DateTime startTime;
            DateTime endTime;
            string subject = "";
            int direction = 2;
            string threadId = "";
            string datasource = "ACDJABDS";
            string parentId = string.Empty;
            // string sourceType = "ExpertFlow HybriChat";
             string sourceSubType = "Chats";
            string actor = "";
            string conversationtype = "InstantMessage";

    LLA_Model.verint_interface retturnmeeesgae = new LLA_Model.verint_interface { };
            try
            {

                DateTime currtime = DateTime.Now;
                DateTime yesttime = currtime.AddDays(-1);
                //string urlpart = "/conversations/getAllConversations?start_time= " + yesttime.ToString("yyyy-mm-dd") + "%2000:00:01&end_time=" + currtime.ToString("yyyy-mm-dd") + "%2023:11:59";
                string urlpart = "/conversations/getAllConversations?start_time=2021-05-21%2000:00:01&end_time=2021-06-06%2023:11:59";
                var deserializer = new RestSharp.Serialization.Json.JsonDeserializer();
                logerror("Going to get Hybrid Chat URL from DB");
                string query = @"select hc_url from endpoints";// where url_name = 'getconversations'";
                //SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["VerintAPICapture"].ConnectionString);
                SqlConnection conn = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=VerintAPICapture;Integrated Security=True;persist security info=True; User ID=sa;pwd=password1$; MultipleActiveResultSets=true");

                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                using (
                    SqlDataReader da = (cmd.ExecuteReader()))
                {
                   // conn.Open();
                    while (da.Read())
                    {
                        cmd.CommandType = CommandType.Text;
                        hcurl = da["hc_url"].ToString().Trim();
                        string getconvourl = hcurl + urlpart;

                        //GET CONVERSTATIONS
                        logerror("Fetching AllConversations from Hybrid Chat MongoDB");
                        var gethcconversations = new RestSharp.RestClient(getconvourl);
                        var getconvorequest = new RestSharp.RestRequest(getconvourl, RestSharp.Method.GET);
                        var hcconversationresponse = gethcconversations.Execute(getconvorequest);
                        //string statcode = hcconversationresponse.StatusCode.ToString();
                        
                        var statcode = hcconversationresponse;
                        if (statcode.StatusCode == HttpStatusCode.OK)
                        {
                            string action = "Conversations Fetched successfully";
                            logerror(action);
                            var deserializer1 = new RestSharp.Serialization.Json.JsonDeserializer();
                            var cooc = deserializer1.Deserialize<List<HC_Model.Root2>>(hcconversationresponse);
                            // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
                            logerror("looping through the conversation IDs");
                            foreach (var looper in cooc)
                            {
                                string convid = looper.id;
                                //GET MESSAGES
                                string getmessageurl_part = "/getMessages?conversationId=" + convid + "";
                                string getmessageurl = hcurl + getmessageurl_part;
                                logerror("Going to fetch All Chats for Conversation_Id: " + convid + " from EF_HybridChat");
                                var gethcmessages = new RestSharp.RestClient(getmessageurl);
                                var getmessagesrequest = new RestSharp.RestRequest(getmessageurl, RestSharp.Method.GET);
                                var hcmessagesresponse = gethcmessages.Execute(getmessagesrequest);
                                int GetMessageStatcode = Convert.ToInt32(hcmessagesresponse.StatusCode);
                                if (GetMessageStatcode == 200)
                                {
                                    string info = "Chats for Conversations_Id: "+looper.id+" fetched successfully";
                                    logerror(info);
                                    var MessageDeserializer = new RestSharp.Serialization.Json.JsonDeserializer();
                                    var messageObj = MessageDeserializer.Deserialize<List<HC_Model.Root>>(hcmessagesresponse);
                                    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
                                    //logerror("Fetched the Messages Successfully through the conversation IDs");
                                    logerror("Creating JSon object for Conversation_Id: " + convid + "");

                                    //CREAT LIST OF ACTOR CLASSES
                                    List<LLA_Model.Actor> ActorList = new List<LLA_Model.Actor>();
                                    //CREAT LIST OF ACTOR UTTERANCES
                                    List<LLA_Model.Utterance> UtteranceList = new List<LLA_Model.Utterance>();
                                   

                                    //CREATE NEW ATTRIBUTE SUBCALSS INSTANCE
                                    LLA_Model.Attributes attributeinst = new LLA_Model.Attributes();
                                    attributeinst.sourceType = "EF-HybridChat";
                                    attributeinst.sourceSubType = "Chat";

                                    //CALL NEW ROOT OBJECT FOR LLA INSTANCE
                                    LLA_Model.verint_interface ObjClass = new LLA_Model.verint_interface();
                                    
                                    ObjClass.language = "en-us";
                                    ObjClass.sourceType = sourceType;
                                    ObjClass.project = "LifeLine Customer Contact Solution";
                                    ObjClass.channel = looper.channel;
                                    ObjClass.startTime = looper.startTime;
                                    ObjClass.endTime = looper.endTime;
                                    ObjClass.subject = "";
                                    ObjClass.direction = 2;
                                    ObjClass.threadId = looper.taskId;
                                    ObjClass.datasource = convid;
                                    ObjClass.parentId = convid;

                                    foreach (var ChatItem in messageObj)
                                    {
                                        //CREATE NEW ACTOR SUBCLASS
                                        LLA_Model.Actor actorsids = new LLA_Model.Actor();
                                        //SETTING THE DYNAMIC PART OF ACTORS CLASS INSTANCE
                                     {
                                            actorsids.id = ChatItem.from.id;
                                            actorsids.email = "";
                                            actorsids.accountId = ChatItem.from.id;
                                            actorsids.role = ChatItem.from.type;
                                            actorsids.displayName = ChatItem.from.name;
                                            actorsids.timezone = "";    
                                            actorsids.enterTime = ChatItem.timestamp;
                                            actorsids.leaveTime = ChatItem.updatedAt;
                                        }
                                        //CONFIRM IF THE ACTOR DOES NOT ALREADY EXIST IN THE LIST OF ACTORS AND PUSH NEW ITEM INTO LIST
                                        bool containsItem = ActorList.Any(item => item.id == actorsids.id);
                                        if (containsItem == false)
                                        {
                                            ActorList.Add(actorsids);
                                        }

                                        //SETTING THE DYNAMIC PART OF UTTERANCE CLASS INSTANCE
                                        //CREATE NEW UTTERANCE SUBCLASS
                                        LLA_Model.Utterance utteranceinst = new LLA_Model.Utterance();
                                        List<string> To = new List<string>();
                                        utteranceinst.language = "en-us";
                                        utteranceinst.actor = ChatItem.from.name;
                                        utteranceinst.to = To;
                                        utteranceinst.startTime = ChatItem.timestamp;
                                        utteranceinst.type = ChatItem.messageType;
                                        utteranceinst.value = ChatItem.text;
                                        utteranceinst.raw_value = ChatItem.text;
                                        // PUSH NEW ITEM INTO LIST
                                         UtteranceList.Add(utteranceinst);
                                       
                                        //SETTING THE DYNAMIC PART OF ROOT CLASS INSTANCE
                                        ObjClass.type = "EF-HybridChat" + ChatItem.messageType;
                                       ObjClass.actors = ActorList ;
                                        ObjClass.attributes = attributeinst;
                                        ObjClass.utterances = UtteranceList;

                                        //NOW ADDING THE DATA TO RESPECTIVE OBJECT ARRAYS

                                    }
                                    //NPW CALLING NTT API TO PUSH THE CHAT TRANSCRIPTS


                                    string LLA_url = "http://sydvertxr01/api/recording/textcapture/v1/ingestion";
                                    string test = "ed067050bbc1a63b285e970cf551dce5";
                                    // geo_json geoprop = new geo_json { type = "Feature", properties = "" };
                                   
                                    var client = new RestSharp.RestClient(LLA_url);
                                    var request = new RestSharp.RestRequest(""+LLA_url+"", RestSharp.Method.POST);
                                    request.AddHeader("UKtLFljf", "B6CEF06DE8BA59FA57ED4F76AC24F56DD6194DB589E414CB5B7E3812FF46944FFEA663CFCB79141DC5A2387A50B045D24360EC7F973D2E9D802B45B1161C21BF");
                                    request.RequestFormat = RestSharp.DataFormat.Json;
                                    request.AddJsonBody(ObjClass);

                                    var response = client.Execute(request);
                                    int V_StatCode = Convert.ToInt32(response.StatusCode);
                                    if (V_StatCode == 201)
                                    {
                                        string V_info = "Successfully pushed Chat Transcript";
                                        logerror(info);
                                        string s = Newtonsoft.Json.JsonConvert.SerializeObject(ObjClass);
                                        logerror(s);
                                    }
                                    else
                                    {
                                        var s = response.StatusCode.ToString();
                                        logerror(s);
                                    }

                                }
                                else //STAT CODE FOR GETTING MESSAGES FOR EACH CONVERSATION ID IS NOT 200 AKA PASS
                                {
                                    retturnmeeesgae.id = "System could not get the Messages for ID: " + convid + "";
                                    LLA_Model.errorobj errorguy = new LLA_Model.errorobj();
                                    errorguy.errorname = "System could not get the Messages for ID: " + convid + "";
                                    logerror(errorguy.errorname);
                                }
                            }
                        }

                        
                        if (statcode.StatusCode != HttpStatusCode.OK)
                        {


                        }
                        else
                        {
                            retturnmeeesgae = new LLA_Model.verint_interface { };
                        }

                    }
                   
                }
                conn.Close();
            }
            catch (Exception e)
            {
                retturnmeeesgae.id = e.Message.ToString();
                LLA_Model.errorobj errorguy = new LLA_Model.errorobj();
                errorguy.errorname = e.ToString();
                logerror(errorguy.errorname);

               // return retturnmeeesgae;
            }
            // return retturnmeeesgae;
            
            Console.ReadLine();
        }
        public static void logger(Exception e)
        {
            StreamWriter loggerman = null;
            try
            {
                // loggerman = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\Log.txt", true);
                loggerman = new StreamWriter(@"C:\Text Capture\Log.txt", true);
                loggerman.WriteLine(DateTime.Now.ToString() + ":" + e.Source.ToString().Trim() + ";" + e.Message.ToString().Trim());
                loggerman.Flush();
                loggerman.Close();
            }
            catch
            { }
        }

        public static void logerror(string messageex)
        {
            StreamWriter custommessage = null;
            //custommessage = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\CustomLog.txt", true);
            custommessage = new StreamWriter(@"C:\Text Capture\CustomLog.txt", true);
            custommessage.WriteLine(DateTime.Now.ToString() + ":" + messageex);
            custommessage.Flush();
            custommessage.Close();
        }

        private RestClient InitializeAndGetClient()
        {
            var cookieJar = new CookieContainer();
            var client = new RestClient("http://sydvertxr01/api/recording/textcapture/v1/ingestion")
            {
                Authenticator = new HttpBasicAuthenticator("UKtLFljf", "B6CEF06DE8BA59FA57ED4F76AC24F56DD6194DB589E414CB5B7E3812FF46944FFEA663CFCB79141DC5A2387A50B045D24360EC7F973D2E9D802B45B1161C21BF"),
                CookieContainer = cookieJar
            };

            return client;
        }

    }
}

